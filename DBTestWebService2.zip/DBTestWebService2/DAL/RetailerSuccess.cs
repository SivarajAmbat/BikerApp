﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
    public class RetailerSuccess
    {
        public string Message { get; set; }
        public string RetailerId { get; set; }
    }
}
