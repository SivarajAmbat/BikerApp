﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;

namespace DAL
{
    public class BikerDAL
    {
        static BikerDAL()
        {
            db = new BikerDataClassesDataContext();
            db.DeferredLoadingEnabled = false;
        }

        public static BikerDataClassesDataContext db;

        OtpClient.ServiceSoapClient otpDb = new OtpClient.ServiceSoapClient();
        public inputmessage BikerLogInCreateOtp(string empid, string imeinumber, string osversion,
            string devicename, string appversion)
        {
            inputmessage msg = new inputmessage();
            try
            {
                System.Data.Linq.ISingleResult<MHrCreateOtpResult> mhrCreateOtpResult = db.MHrCreateOtp(empid, imeinumber, osversion, devicename, appversion);
                if (mhrCreateOtpResult != null)
                {
                    SMSbyWebservice sms = SMSbyWebservice.Instance;
                    var smsTemp = mhrCreateOtpResult.Where(m => m != null && !String.IsNullOrEmpty(m.Biker_Mob))
                    .Select(m => new
                    {
                        EmployeeId = m.Biker_Code,
                        MobileNumber = m.Biker_Mob,
                        OTP = m.otp,
                        Biker_Name = m.Biker_Name,
                        Status = m.Status,
                        Message = m.Message
                    }).FirstOrDefault();

                    if (smsTemp != null)
                    {
                        sms.EmployeeId = smsTemp.EmployeeId;
                        sms.MobileNumber = smsTemp.MobileNumber;
                        sms.OTP = smsTemp.OTP;
                        string returnValue = sms.SendSMS();
                        //string returnValue = otpDb.sendsms(sms.MobileNumber, BodyMessage(sms.Biker_Name, sms.OTP), sms.Biker_Name, "pass@1234");// 

                        msg.Code = smsTemp.Status;
                        msg.des = smsTemp.Message;
                        return msg;
                    }

                    //if (!String.IsNullOrEmpty(dt.Rows[0][1].ToString()))
                    //{
                    //    string body = BodyMessage(dt.Rows[0][1].ToString(), dt.Rows[0][4].ToString());
                    //    mailsql m2 = new mailsql(dt.Rows[0][2].ToString(), "not", "not", "Luminous_mobileApp One Time Password", body, "");
                    //    m2.sendMaildb();
                    //}
                }
                else
                {
                    msg.Code = "ERROR";
                    msg.des = "Invalid Employee";
                    return msg;
                }
            }
            catch (Exception ex)
            {
                LogException(ex, "BikerLogInCreateOtp, empid | " + empid + ", imeinumber | " + imeinumber + ", osversion | " + osversion + ", devicename | " + devicename + ", appversion | " + appversion);
            }
            return msg;
        }

        private void LogException(Exception ex, string createdBy)
        {
            try
            {
                if (ex != null)
                {
                    Logger log = new Logger { Message = ex.Message, StackTrace = ex.StackTrace, CreatedOn = DateTime.Now, CreatedBy = createdBy };
                    db.Loggers.InsertOnSubmit(log);
                    db.SubmitChanges();
                }
            }
            catch (Exception)
            {
            }
        }

        private string BodyMessage(string Biker_Name, string OTP)
        {
            return "Your one time password is " + OTP + ". It will  expire in 30 minutes";
        }

        public bool CheckRetailerAssigned(string BikerLoginId)
        {
            return true;
        }

        public inputmessage OTPAuthentication(string empid, string imeinumber,
            string osversion, string devicename, string otp, string appid, string devid, string ostype)
        {
            inputmessage msg = new inputmessage();
            try
            {
                System.Data.Linq.ISingleResult<MHrVarifyOtpNotificationResult> mhrVarifyOtpNotificationResult =
                        db.MHrVarifyOtpNotification(empid, imeinumber, osversion, devicename, otp, appid, devid, ostype);
                if (mhrVarifyOtpNotificationResult != null)
                {
                    inputmessage inputMessage = mhrVarifyOtpNotificationResult.Where(m => m != null)
                        .Select(m => new inputmessage { Code = m.Code, des = m.Message }).FirstOrDefault();
                    if (inputMessage != null)
                    {
                        msg.Code = inputMessage.Code;
                        msg.des = inputMessage.des;
                    }
                    else
                    {
                        msg.Code = inputMessage.Code;
                        msg.des = inputMessage.des;
                    }
                }
                else
                {
                    msg.Code = "ERROR";
                    msg.des = "Please try again";
                }
            }
            catch (Exception ex)
            {
                LogException(ex, "OTPAuthentication, empid | " + empid + ", imeinumber | " + imeinumber + ", osversion | " + osversion + ", devicename | " + devicename + ", otp | " + otp + ", appid | " + appid + ", devid | " + devid + ", ostype | " + ostype);
            }
            return msg;
        }

        public List<DistDealerDetail> GetDistributors(string BikersLogInId)
        {
            List<DistDealerDetail> distDealerDetail = null;
            try
            {
                System.Data.Linq.ISingleResult<SP_GetDistributors_By_BikersLogInIdResult> getDistributorModels = db.SP_GetDistributors_By_BikersLogInId(BikersLogInId);
                if (getDistributorModels != null && getDistributorModels.Count() > 0)
                    distDealerDetail = db.SP_GetDistributors_By_BikersLogInId(BikersLogInId).Select(m => new DistDealerDetail { ID = m.ID, Customer_Type = m.Customer_Type, Dis_Sap_Code = m.Dis_Sap_Code, Dis_Name = m.Dis_Name }).ToList();
            }
            catch (Exception ex)
            {
                LogException(ex, "GetDistributors, BikersLogInId | " + BikersLogInId);
            }
            return distDealerDetail;
        }

        public List<Item> GetItems()
        {
            List<Item> items = null;
            try
            {
                System.Data.Linq.ISingleResult<SP_GetItemsResult> sp_GetItemsResult = db.SP_GetItems();
                if (sp_GetItemsResult != null && sp_GetItemsResult.Count() > 0)
                    items = db.SP_GetItems().Select(m => new Item { ID = m.ID, ItemName = m.ItemName }).ToList();
            }
            catch (Exception ex)
            {
                LogException(ex, "GetItems");
            }
            return items;
        }

        public List<BeatDetail> GetBeatList(string BDistributorId, string BikersLogInId)
        {
            List<BeatDetail> beatDetails = null;
            try
            {
                System.Data.Linq.ISingleResult<SP_GetBeatList_By_DistId_BikerIdResult> sp_GetBeatList_By_DistId_BikerIdResult = db.SP_GetBeatList_By_DistId_BikerId(BDistributorId, BikersLogInId);
                if (sp_GetBeatList_By_DistId_BikerIdResult != null && sp_GetBeatList_By_DistId_BikerIdResult.Count() > 0)
                    beatDetails = db.SP_GetBeatList_By_DistId_BikerId(BDistributorId, BikersLogInId).Select(m => new BeatDetail { ID = m.ID, Code = m.Code, Name = m.Name }).ToList();
            }
            catch (Exception ex)
            {
                LogException(ex, "BikersLogInId | " + BikersLogInId + ",BDistributorId | " + BDistributorId);
            }
            return beatDetails;
        }

        public List<RetailerDetail> GetRetailerList(string BeatId, string BDistributorId, string BikersLogInd, string SearchStringRetailerName)
        {
            List<RetailerDetail> retailerDetails = null;
            try
            {
                System.Data.Linq.ISingleResult<SP_GetRetailerList_By_BeatId_DistId_BikerIdResult> sp_GetRetailerList_By_BeatId_DistId_BikerIdResult = db.SP_GetRetailerList_By_BeatId_DistId_BikerId(BeatId, BDistributorId, BikersLogInd, SearchStringRetailerName);
                if (sp_GetRetailerList_By_BeatId_DistId_BikerIdResult != null && sp_GetRetailerList_By_BeatId_DistId_BikerIdResult.Count() > 0)
                    retailerDetails = db.SP_GetRetailerList_By_BeatId_DistId_BikerId(BeatId, BDistributorId, BikersLogInd, SearchStringRetailerName).Select(m => new RetailerDetail { ID = m.ID, Code = m.Code, Name = m.Name, Contact_Number = m.Contact_Number, Address = m.Address, State = m.State, CityArea = m.CityArea, Pin_Code = m.Pin_Code, Contact_person = m.Contact_person }).ToList();
            }
            catch (Exception ex)
            {
                LogException(ex, "GetRetailerList, " + "BikersLogInId | " + BikersLogInd + ",BDistributorId | " + BDistributorId + "BeatId | " + BeatId + "SearchStringRetailerName | " + SearchStringRetailerName);
            }
            return retailerDetails;
        }


        /* Original:
         * 
         * 
        public List<RetailerDetail> GetRetailerListByName(string RetailerName)
        {
            List<RetailerDetail> retalersResult = null;
            List<RetailerDetail> retalers = db.RetailerDetails.Where(m => !String.IsNullOrEmpty(m.Active_Status)&& m.Active_Status == "Active" && m.Name.Contains(RetailerName)).ToList();
            if (retalers != null && retalers.Count > 0)
                retalersResult = retalers.Select(m =>
                new RetailerDetail
                {
                    ID = m.ID,
                    Code = m.Code,
                    Name = m.Name,
                    Contact_Number = m.Contact_Number,
                    Address = m.Address,
                    State = m.State,
                    CityArea = m.CityArea,
                    Pin_Code = m.Pin_Code
                }).ToList();
            return retalersResult;
        }
         */

        public List<RetailerDetail> GetRetailerListByName(string bikersloginid, string searchstringretailername)
        {
            List<RetailerDetail> retailerDetails = null;
            try
            {
                var sp_GetRetailerList_By_BikerIdResult = db.SP_GetRetailerList_By_BikerId(bikersloginid, searchstringretailername);
                if (sp_GetRetailerList_By_BikerIdResult != null && sp_GetRetailerList_By_BikerIdResult.Count() > 0)
                    retailerDetails = db.SP_GetRetailerList_By_BikerId(bikersloginid, searchstringretailername)
                        .Select(m => new RetailerDetail { ID = m.ID, Code = m.Code, Name = m.Name, Contact_Number = m.Contact_Number, Address = m.Address, State = m.State, CityArea = m.CityArea, Pin_Code = m.Pin_Code, Contact_person = m.Contact_person }).ToList();
            }
            catch (Exception ex)
            {
                LogException(ex, "GetRetailerListByName, " + "BikersLogInId | " + bikersloginid + "searchstringretailername | " + searchstringretailername);
            }
            return retailerDetails;
        }

        public ResultMessage SaveNewOrder(string DestributorId, string RetailerId, string BeatId, string BikerLogInId,
            DateTime DateOfVisit, string Visisted, string Sold, string Status, List<OrderItemSave> OrderItemsSave) //int ItemsID, int RequiredQuantity, int SuppliedQuantity
        {
            ResultMessage message = new ResultMessage { Message = "Faliure", OrderId = 0 };
            try
            {
                int dist_ID = db.DistDealerDetails.Where(m => m.Dis_Sap_Code == DestributorId).Select(m => m.ID).FirstOrDefault();
                int Retailer_ID = db.RetailerDetails.Where(m => m.Code == RetailerId).Select(m => m.ID).FirstOrDefault();
                int Beat_ID = db.BeatDetails.Where(m => m.Code == BeatId).Select(m => m.ID).FirstOrDefault();

                OrderDetail orderDetails = new OrderDetail
                {
                    Date_Of_Visit = DateOfVisit,
                    Distributor_Id = dist_ID,
                    //Dis_Sap_Code = m.DistDealerDetail.Dis_Sap_Code,
                    //Dis_Name = m.DistDealerDetail.Dis_Name,
                    Beat_Id = Beat_ID,
                    //Beat_Code = m.BeatDetail.Code,
                    //Beat_Name = m.BeatDetail.Name,
                    Retailer_Id = Retailer_ID,
                    //Retailer_Code = m.RetailerDetail.Code,
                    //Retailer_Name = m.RetailerDetail.Name,
                    Visted = (!String.IsNullOrEmpty(Visisted) && Visisted.ToLower() == "yes") ? true : false,
                    Sold = (!String.IsNullOrEmpty(Sold) && Sold.ToLower() == "yes") ? true : false,
                    Status = Status,
                    Ordered_On = DateTime.Now,
                    Order_By = BikerLogInId
                };

                db.OrderDetails.InsertOnSubmit(orderDetails);
                db.SubmitChanges();

                if (OrderItemsSave != null && OrderItemsSave.Count > 0 && orderDetails.ID > 0)
                {
                    List<OrderItem> orderItems = new List<OrderItem>();
                    foreach (OrderItemSave OrderItemSaveObj in OrderItemsSave)
                    {
                        orderItems.Add(new OrderItem
                        {
                            Item_Id = OrderItemSaveObj.Item_Id,
                            Order_Id = orderDetails.ID,
                            Required_Quantity = OrderItemSaveObj.Required_Quantity,
                            Created_By = BikerLogInId,
                            Created_On = DateTime.Now
                        });
                    }

                    db.OrderItems.InsertAllOnSubmit(orderItems);
                    db.SubmitChanges();
                }

                //int result = 0;
                //System.Data.Linq.ISingleResult<SP_SaveNewOrderResult> sp_SaveNewOrderResult = db.SP_SaveNewOrder(DestributorId, RetailerId, BeatId, BikerLogInId, DateOfVisit, Visisted, Sold, Status, ItemsID, RequiredQuantity, SuppliedQuantity);
                //if (sp_SaveNewOrderResult != null)
                //{
                //    SP_SaveNewOrderResult obj = sp_SaveNewOrderResult.FirstOrDefault();
                //    if(obj != null)
                //        result = obj.Column1;
                //}
                //if (result == 1)
                if (orderDetails.ID > 0)
                    message = new ResultMessage { Message = "Success", OrderId = orderDetails.ID };
            }
            catch (Exception ex)
            {

                message = new ResultMessage { Message = "Faliure", OrderId = 0 };
                LogException(ex, "SaveNewOrder, " + ",DestributorId | " + DestributorId + ",RetailerId | " + RetailerId + ",BeatId | " + BeatId + ",BikerLogInId | " + BikerLogInId + ",DateOfVisit | " + DateOfVisit.ToString() + ",Visisted | " + Visisted + ",Sold | " + Sold + ",Status | " + Status + ",OrderItemsSave | " + ((OrderItemsSave != null) ? OrderItemsSave.Count : 0));
            }
            return message;
        }

        public List<OrderIdBeatIdRetailId> GetOrders(string DestributorId, string BikerLogInId, string status, string RetailerId)
        {

            try
            {
                DistDealerDetail disDetail = null;
                if (!String.IsNullOrEmpty(DestributorId) && DestributorId.ToLower() != "null")
                    disDetail = db.DistDealerDetails.Where(m => m.Dis_Sap_Code == DestributorId).FirstOrDefault();
                RetailerDetail retDetail = null;
                if (!String.IsNullOrEmpty(RetailerId) && RetailerId.ToLower() != "null")
                    retDetail = db.RetailerDetails.Where(m => m.Code == RetailerId).FirstOrDefault();

                int distId = (disDetail != null) ? disDetail.ID : 0;
                int retId = (retDetail != null) ? retDetail.ID : 0;



                //&& k.Distributor_Id == ((distId == 0) ? k.Distributor_Id : distId)
                //&& k.Retailer_Id == ((retId == 0) ? k.Retailer_Id : retId)

                List<OrderDetailed> OrderDetails = db.OrderDetails
                    .Where(k => k.Distributor_Id == ((distId == 0) ? k.Distributor_Id : distId)
                    && k.Retailer_Id == ((retId == 0) ? k.Retailer_Id : retId)
                         && k.Order_By == BikerLogInId && k.Status.ToLower() == (status.ToLower() == "all" ? k.Status : status.ToLower()))
                    .Select(
                    m => new OrderDetailed
                    {
                        Order_ID = m.ID,
                        //Date_Of_Visit = m.Date_Of_Visit,
                        //Distributor_Id = m.Distributor_Id,
                        Dis_Sap_Code = m.DistDealerDetail.Dis_Sap_Code,
                        Dis_Name = m.DistDealerDetail.Dis_Name,
                        //Beat_Id = m.Beat_Id,
                        Beat_Code = m.BeatDetail.Code,
                        Beat_Name = m.BeatDetail.Name,
                        //Retailer_Id = m.Retailer_Id,
                        Retailer_Code = m.RetailerDetail.Code,
                        Retailer_Name = m.RetailerDetail.Name,
                        //Visted = m.Visted,
                        //Sold = m.Sold,
                        Status = m.Status,
                        //Ordered_On = m.Ordered_On,
                        //Order_By = m.Order_By,
                        //Updated_On = m.Updated_On,
                        //Updated_By = m.Updated_By,
                        //OrderItems = m.OrderItems.Select(n => new OrderDetailedItem
                        //{
                        //    ID = n.ID,
                        //    Order_Id = n.Order_Id,
                        //    Item_Id = n.Item_Id,
                        //    ItemName = n.Item.ItemName,
                        //    Required_Quantity = n.Required_Quantity,
                        //    Pending_Quantity = (n.Required_Quantity - n.Supplied_Quantity),
                        //    Supplied_Quantity = n.Supplied_Quantity,
                        //    Created_On = n.Created_On,
                        //    Created_By = n.Created_By,
                        //    Updated_On = n.Updated_On,
                        //    Updated_By = n.Updated_By
                        //}).ToList()
                    }).ToList();
                if (OrderDetails != null)
                {
                    List<OrderIdBeatIdRetailId> OrderIdBeatIdRetailIds = new List<OrderIdBeatIdRetailId>();
                    OrderIdBeatIdRetailIds.AddRange(OrderDetails.Select(m => new OrderIdBeatIdRetailId
                    {
                        Order_ID = m.Order_ID,
                        Beat_Code = m.Beat_Code,
                        Beat_Name = m.Beat_Name,
                        Retailer_Code = m.Retailer_Code,
                        Retailer_Name = m.Retailer_Name,
                        Destributor_Code = m.Dis_Sap_Code,
                        Destributor_Name = m.Dis_Name
                    }).Distinct().ToList());
                    return OrderIdBeatIdRetailIds;
                }
            }
            catch (Exception ex)
            {
                LogException(ex, "GetOrders, " + ",DestributorId | " + DestributorId + ",RetailerId | " + RetailerId + ",BikerLogInId | " + BikerLogInId + ",Status | " + status);
            }
            return new List<OrderIdBeatIdRetailId>();
        }

        public OrderDetailed OrderDetails(int OrderId)
        {


            OrderDetailed orderDetailed = null;
            try
            {
                orderDetailed = db.OrderDetails.Where(k => k.ID == OrderId).Select(
                       m => new OrderDetailed
                       {
                           Order_ID = m.ID,
                           //Date_Of_Visit = m.Date_Of_Visit,
                           //Distributor_Id = m.Distributor_Id,
                           Dis_Sap_Code = m.DistDealerDetail.Dis_Sap_Code,
                           Dis_Name = m.DistDealerDetail.Dis_Name,
                           //Beat_Id = m.Beat_Id,
                           Beat_Code = m.BeatDetail.Code,
                           Beat_Name = m.BeatDetail.Name,
                           //Retailer_Id = m.Retailer_Id,
                           Retailer_Code = m.RetailerDetail.Code,
                           Retailer_Name = m.RetailerDetail.Name,
                           //Visted = m.Visted,
                           //Sold = m.Sold,
                           Status = m.Status,
                           //Ordered_On = m.Ordered_On,
                           //Order_By = m.Order_By,
                           //Updated_On = m.Updated_On,
                           //Updated_By = m.Updated_By,
                           //OrderItems = 

                       }).FirstOrDefault();



                OrderDetail orderDetailTemp = db.OrderDetails
                    //.Include(k => k.OrderItems)
                    .Where(k => k.ID == OrderId).FirstOrDefault();


                //if (orderDetailTemp != null)
                //{
                List<OrderDetailedItem> orderDetailedItems = db.OrderItems
                    .Where(n => n.Order_Id == OrderId)
                    .Select(n => new OrderDetailedItem
                {
                    ID = n.ID,
                    Order_Id = n.Order_Id,
                    Item_Id = n.Item_Id,
                    ItemName = n.Item.ItemName,
                    Required_Quantity = ((n.Required_Quantity == null) ? 0 : n.Required_Quantity),
                    Pending_Quantity = (((n.Required_Quantity == null) ? 0 : n.Required_Quantity) - ((n.Supplied_Quantity == null) ? 0 : n.Supplied_Quantity)),
                    Supplied_Quantity = ((n.Supplied_Quantity == null) ? 0 : n.Supplied_Quantity),
                    Created_On = n.Created_On,
                    Created_By = n.Created_By,
                    Updated_On = n.Updated_On,
                    Updated_By = n.Updated_By
                }).ToList();


                if (orderDetailedItems != null && orderDetailedItems.Count > 0)
                {
                    foreach (OrderDetailedItem item in orderDetailedItems)
                    {
                        if (item.ItemName.ToLower() == "fan")
                        {
                            orderDetailed.Item_Id_Fan = (item.Item_Id == null) ? 0 : Convert.ToInt32(item.Item_Id);
                            orderDetailed.Item_Fan_Name = item.ItemName;
                            orderDetailed.Required_FanQuantity = (item.Required_Quantity == null) ? 0 : Convert.ToInt32(item.Required_Quantity);
                            orderDetailed.Pending_FanQuantity = (item.Pending_Quantity == null) ? ((orderDetailed.Status.ToLower() == "completed") ? 0 : orderDetailed.Required_FanQuantity) : Convert.ToInt32(item.Pending_Quantity);
                        }
                        else if (item.ItemName.ToLower() == "wire")
                        {
                            orderDetailed.Item_Id_Wire = (item.Item_Id == null) ? 0 : Convert.ToInt32(item.Item_Id);
                            orderDetailed.Item_Wire_Name = item.ItemName;
                            orderDetailed.Required_WireQuantity = (item.Required_Quantity == null) ? 0 : Convert.ToInt32(item.Required_Quantity);
                            orderDetailed.Pending_WireQuantity = (item.Pending_Quantity == null) ? ((orderDetailed.Status.ToLower() == "completed") ? 0 : orderDetailed.Required_FanQuantity) : Convert.ToInt32(item.Pending_Quantity);
                        }
                        else if (item.ItemName.ToLower() == "lighting")
                        {
                            orderDetailed.Item_Id_Lighting = (item.Item_Id == null) ? 0 : Convert.ToInt32(item.Item_Id);
                            orderDetailed.Item_Light_Name = item.ItemName;
                            orderDetailed.Required_LightQuantity = (item.Required_Quantity == null) ? 0 : Convert.ToInt32(item.Required_Quantity);
                            orderDetailed.Pending_LightQuantity = (item.Pending_Quantity == null) ? ((orderDetailed.Status.ToLower() == "completed") ? 0 : orderDetailed.Required_FanQuantity) : Convert.ToInt32(item.Pending_Quantity);
                        }
                    }
                    //}
                }



            }
            catch (Exception ex)
            {
                LogException(ex, "OrderDetails, " + ",OrderId | " + OrderId);
            }

            return orderDetailed;
        }

        public string UpateOrder(List<OrderItemUpdate> orderItemUpdate, string status)
        {
            string message = "Faliure";
            try
            {
                OrderDetail orderDetails = db.OrderDetails.Where(m => m.ID == orderItemUpdate.FirstOrDefault().Order_Id).FirstOrDefault();
                if (orderDetails != null)
                {
                    orderDetails.Status = status;
                    orderDetails.Updated_On = DateTime.Now;
                    orderDetails.Updated_By = orderDetails.Order_By;
                    //db.OrderDetails.Attach(orderDetails);
                    db.SubmitChanges();

                    if (orderDetails != null && db.OrderItems != null)
                    {
                        List<OrderItem> orderItmeToUpdate = new List<OrderItem>();
                        List<OrderItem> orderItemsTemp = db.OrderItems.Where(m => m.Order_Id == orderDetails.ID).ToList();
                        foreach (OrderItem item in orderItemsTemp)
                        {
                            if (orderItemUpdate.Where(m => m.Item_Id == item.Item_Id).FirstOrDefault() != null)
                            {
                                item.Supplied_Quantity = ((item.Supplied_Quantity == null) ? 0 : item.Supplied_Quantity) + ((orderItemUpdate.Where(m => m.Item_Id == item.Item_Id).FirstOrDefault().Supplied_Quantity == null) ? 0 : orderItemUpdate.Where(m => m.Item_Id == item.Item_Id).FirstOrDefault().Supplied_Quantity);
                                item.Updated_On = DateTime.Now;
                                item.Updated_By = orderDetails.Order_By;
                            }

                            orderItmeToUpdate.Add(item);
                        }
                        if (orderItmeToUpdate != null && orderItmeToUpdate.Count > 0)
                        {
                            //db.OrderItems.AttachAll(orderItmeToUpdate);
                            db.SubmitChanges();
                            message = "Success";
                        }
                    }
                    message = "Success";
                }
            }
            catch (Exception ex)
            {
                message = "Faliure";
                LogException(ex, "UpateOrder, " + ",orderItemUpdate | " + ((orderItemUpdate != null) ? orderItemUpdate.Count : 0) + ",status | " + status);
            }
            return message;
        }

        public RetailerSuccess AddRetailer(string Name, string Contact_person, string State, string City, string Address, string Pin_Code, string Contact_Number, string Status, DateTime DateOfJoining)
        {
            RetailerSuccess result = new RetailerSuccess { Message = "Faliure", RetailerId = "" };
            try
            {
                //if (String.IsNullOrEmpty(Code))
                //    return new RetailerSuccess { Message = "Code is required", RetailerId = 0 };
                if (String.IsNullOrEmpty(Name))
                    return new RetailerSuccess { Message = "Name is required", RetailerId = "" };
                if (String.IsNullOrEmpty(Contact_Number))
                    return new RetailerSuccess { Message = "Contact_Number is required", RetailerId = "" };

                /* Modified for CR dt. 7/4/2016 : BEGIN */
                
                if (IsContactNumberPresent(Contact_Number))
                {
                    return new RetailerSuccess { Message = "Duplicate Contact_Number", RetailerId = "" };
                }

                /* Modified for CR dt. 7/4/2016 : END */


                List<double> codes = db.RetailerDetails.Where(m => m.IsCreatedByBiker != null && Convert.ToBoolean(m.IsCreatedByBiker))
                    .Select(m => Convert.ToDouble(m.Code)).ToList();
                string code = string.Empty;
                if (codes != null && codes.Count > 0)
                    code = Convert.ToString(db.RetailerDetails.Where(m => m.IsCreatedByBiker != null && Convert.ToBoolean(m.IsCreatedByBiker))
                        .Select(m => Convert.ToDouble(m.Code)).ToList().Max() + 1);
                else
                    code = "6000000001";

                RetailerDetail retailerDetail = new RetailerDetail
                    {
                        Code = (!String.IsNullOrEmpty(code) ? code : "6000000001"),
                        Name = Name,
                        Contact_person = Contact_person,
                        State = State,
                        CityArea = City,
                        Address = Address,
                        Pin_Code = Pin_Code,
                        Contact_Number = Contact_Number,
                        Active_Status = Status,
                        Date_Of_Joining = DateOfJoining,
                        IsCreatedByBiker = true
                    };

                db.RetailerDetails.InsertOnSubmit(retailerDetail);
                db.SubmitChanges();
                if (retailerDetail != null && retailerDetail.ID > 0)
                    result = result = new RetailerSuccess { Message = "Success", RetailerId = retailerDetail.Code };
                SendMail(retailerDetail);
            }
            catch (Exception ex)
            {
                LogException(ex, "AddRetailer, Name | " + ", Contact_person | " + Contact_person + ", State | " + State + ", City | " + City + ", Address | " + Address + ", Pin_Code | " + Pin_Code + ", Contact_Number | " + Contact_Number);
            }
            return result;
        }

        private bool IsContactNumberPresent(string Contact_Number)
        {
            return db.RetailerDetails.Any(m => m.Contact_Number.Equals(Contact_Number));
        }

        private void SendMail(RetailerDetail retailerDetail)
        {
            //Comma Seperated From and To Mail address will be provided in Web.Config file under AppSettings. To Address can be comma seperated mail address.
            System.Net.Mail.MailMessage message = new System.Net.Mail.MailMessage();
            List<string> toMailIds = ConfigurationSettings.AppSettings["ToMailId"].Split(',').ToList();
            foreach (string mailId in toMailIds)
            {
                message.To.Add(mailId.Trim());
            }
            message.Subject = "New Retailer added awaiting your approval";
            message.From = new System.Net.Mail.MailAddress(ConfigurationSettings.AppSettings["FromMailId"]);
            message.Body = "New Retailer has been added. <br/> Retailer Code : " + retailerDetail.Code + "<br/> Please login to Biker Management Portal to activate and Map to Beat and Biker.";
            message.IsBodyHtml = true;
            System.Net.Mail.SmtpClient smtp = new System.Net.Mail.SmtpClient(ConfigurationSettings.AppSettings["SMTPSERVER"]);
            smtp.Port = Convert.ToInt32(ConfigurationSettings.AppSettings["SMTPPORT"]);
            smtp.Credentials = new NetworkCredential(ConfigurationSettings.AppSettings["SMTPUSERNAME"], ConfigurationSettings.AppSettings["SMTPPASSWORD"]);
            smtp.Send(message);
        }

        public BikerTargetAchieved GetBikerMonthTarget(string BikerLoginId, int Month, int Year)
        {
            BikerTargetAchieved bikerTargetAchieved = new BikerTargetAchieved();
            try
            {
                List<BikerTarget> bikerTargets = db.BikerTargets.Join(db.BikerBoyDetails, m => m.BikerId, n => n.ID, (m, n) => new { m, n })
                    .Where(m => m.n.BB_Code == BikerLoginId
                    && m.m.MonthNumber == Month && m.m.YearNumber == Year).Select(m => m.m).ToList();
                List<OrderItem> orderItems = db.OrderItems.Where(m => (m.Created_On.Value.Year == Year || m.Updated_On.Value.Year == Year)
                    && (m.Created_On.Value.Month == Month || m.Updated_On.Value.Month == Month))
                    .Join(db.OrderDetails, m => m.Order_Id, n => n.ID, (m, n) => new { m, n })
                    .Where(p => p.n.Order_By == BikerLoginId).Select(p => p.m).ToList();

                bikerTargetAchieved.ItemFanName = "Fan";
                bikerTargetAchieved.ItemWireName = "Wire";
                bikerTargetAchieved.ItemLightingName = "Lighting";

                if (bikerTargets != null && bikerTargets.Count > 0)
                {
                    //if (orderItems.Where(m => m.Item_Id == 1).FirstOrDefault() != null)
                    bikerTargetAchieved.CurrentMonthTargerFan = Convert.ToDouble(bikerTargets.Where(m => m.ItemId == 1).Sum(m => m.TargetQuantity));
                    //if (orderItems.Where(m => m.Item_Id == 2).FirstOrDefault() != null)
                    bikerTargetAchieved.CurrentMonthTargerWire = Convert.ToDouble(bikerTargets.Where(m => m.ItemId == 2).Sum(m => m.TargetQuantity));
                    // if (orderItems.Where(m => m.Item_Id == 3).FirstOrDefault() != null)
                    bikerTargetAchieved.CurrentMonthTargerLighting = Convert.ToDouble(bikerTargets.Where(m => m.ItemId == 3).Sum(m => m.TargetQuantity));
                }
                if (orderItems != null && orderItems.Count > 0)
                {
                    if (orderItems.Where(m => m.Item_Id == 1).FirstOrDefault() != null)
                        bikerTargetAchieved.CurrentMonthAchievementFan = Convert.ToDouble(orderItems.Where(m => m.Item_Id == 1).Select(m => m.Required_Quantity).Sum());
                    if (orderItems.Where(m => m.Item_Id == 2).FirstOrDefault() != null)
                        bikerTargetAchieved.CurrentMonthAchievementWire = Convert.ToDouble(orderItems.Where(m => m.Item_Id == 2).Select(m => m.Required_Quantity).Sum());
                    if (orderItems.Where(m => m.Item_Id == 3).FirstOrDefault() != null)
                        bikerTargetAchieved.CurrentMonthAchievementLighting = Convert.ToDouble(orderItems.Where(m => m.Item_Id == 3).Select(m => m.Required_Quantity).Sum());

                    /* Modified for CR dt. 7/4/2016 : BEGIN */
                    if (orderItems.Where(m => m.Item_Id == 1).FirstOrDefault() != null)
                        bikerTargetAchieved.CurrentMonthSuppliedFan = Convert.ToDouble(orderItems.Where(m => m.Item_Id == 1).Select(m => m.Supplied_Quantity).Sum());
                    if (orderItems.Where(m => m.Item_Id == 2).FirstOrDefault() != null)
                        bikerTargetAchieved.CurrentMonthSuppliedWire = Convert.ToDouble(orderItems.Where(m => m.Item_Id == 2).Select(m => m.Supplied_Quantity).Sum());
                    if (orderItems.Where(m => m.Item_Id == 3).FirstOrDefault() != null)
                        bikerTargetAchieved.CurrentMonthSuppliedLighting = Convert.ToDouble(orderItems.Where(m => m.Item_Id == 3).Select(m => m.Supplied_Quantity).Sum());
                    /* Modified for CR dt. 7/4/2016 : END */

                }
            }
            catch (Exception ex)
            {
                LogException(ex, "GetBikerMonthTarget, " + ", BikerLoginId | " + BikerLoginId + ", Month | " + Month + ", Year | " + Year);
            }

            return bikerTargetAchieved;

        }
    }
}
