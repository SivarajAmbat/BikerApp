﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Luminous.Biker.Web.Models
{
    public class BikerTargetCustom
    {
        public BikerTarget BikerTargetFan { get; set; }
        public BikerTarget BikerTargetWire { get; set; }
        public BikerTarget BikerTargetLighting { get; set; }
    }
}