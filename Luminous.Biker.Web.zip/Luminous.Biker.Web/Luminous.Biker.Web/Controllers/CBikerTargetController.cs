﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Luminous.Biker.Web.Models;

namespace Luminous.Biker.Web.Controllers
{
    public class CBikerTargetController : Controller
    {
        private LuminousBikerAppEntities db = new LuminousBikerAppEntities();

        // GET: /CBikerTarget/
        public ActionResult Index()
        {
            var bikertargets = db.BikerTargets.Include(b => b.BikerBoyDetail).Include(b => b.Item);
            return View(bikertargets.ToList());
        }

        // GET: /CBikerTarget/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            BikerTarget bikertarget = db.BikerTargets.Find(id);
            if (bikertarget == null)
            {
                return HttpNotFound();
            }
            return View(bikertarget);
        }

        // GET: /CBikerTarget/Create
        public ActionResult Create()
        {
            ViewBag.BikerId = new SelectList(db.BikerBoyDetails, "ID", "BB_Code");
            ViewBag.ItemId = new SelectList(db.Items, "ID", "ItemName");
            return View();
        }

        // POST: /CBikerTarget/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create1(BikerTargetCustom bikerTargetCustom)
        {
            if (ModelState.IsValid)
            {
                if (bikerTargetCustom != null && bikerTargetCustom.BikerTargetFan != null)
                {
                    BikerTarget bikerTarget = bikerTargetCustom.BikerTargetFan;
                    bikerTarget.CreatedOn = DateTime.Now;
                    bikerTarget.CreateBy = User.Identity.Name;
                    db.BikerTargets.Add(bikerTarget);
                    db.SaveChanges();
                }
                if (bikerTargetCustom != null && bikerTargetCustom.BikerTargetFan != null)
                {
                    BikerTarget bikerTarget = bikerTargetCustom.BikerTargetWire;
                    bikerTarget.CreatedOn = DateTime.Now;
                    bikerTarget.CreateBy = User.Identity.Name;
                    db.BikerTargets.Add(bikerTarget);
                    db.SaveChanges();
                }
                if (bikerTargetCustom != null && bikerTargetCustom.BikerTargetFan != null)
                {
                    BikerTarget bikerTarget = bikerTargetCustom.BikerTargetLighting;
                    bikerTarget.CreatedOn = DateTime.Now;
                    bikerTarget.CreateBy = User.Identity.Name;
                    db.BikerTargets.Add(bikerTarget);
                    db.SaveChanges();
                }
               
                return RedirectToAction("Index");
            }

            ViewBag.BikerId = new SelectList(db.BikerBoyDetails, "ID", "BB_Code", bikerTargetCustom.BikerTargetFan.BikerId);
            ViewBag.ItemId = new SelectList(db.Items, "ID", "ItemName", bikerTargetCustom.BikerTargetFan.ItemId);
            return View(bikerTargetCustom);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(BikerTarget bikerTarget)
        {
            if (ModelState.IsValid)
            {
                if (bikerTarget != null)
                {
                    bikerTarget.CreatedOn = DateTime.Now;
                    bikerTarget.CreateBy = User.Identity.Name;
                    db.BikerTargets.Add(bikerTarget);
                    db.SaveChanges();
                }
                return RedirectToAction("Index");
            }

            ViewBag.BikerId = new SelectList(db.BikerBoyDetails, "ID", "BB_Code", bikerTarget.BikerId);
            ViewBag.ItemId = new SelectList(db.Items, "ID", "ItemName", bikerTarget.ItemId);
            return View(bikerTarget);
        }

        // GET: /CBikerTarget/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            BikerTarget bikertarget = db.BikerTargets.Find(id);
            if (bikertarget == null)
            {
                return HttpNotFound();
            }
            ViewBag.BikerId = new SelectList(db.BikerBoyDetails, "ID", "BB_Code", bikertarget.BikerId);
            ViewBag.ItemId = new SelectList(db.Items, "ID", "ItemName", bikertarget.ItemId);
            return View(bikertarget);
        }

        // POST: /CBikerTarget/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include="Id,BikerId,ItemId,TargetQuantity,CreatedOn,CreateBy,UpdatedOn,UpdatedBy,YearNumber,MonthNumber")] BikerTarget bikertarget)
        {
            if (ModelState.IsValid)
            {
                bikertarget.UpdatedOn = DateTime.Now;
                bikertarget.UpdatedBy = User.Identity.Name;
                db.Entry(bikertarget).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.BikerId = new SelectList(db.BikerBoyDetails, "ID", "BB_Code", bikertarget.BikerId);
            ViewBag.ItemId = new SelectList(db.Items, "ID", "ItemName", bikertarget.ItemId);
            return View(bikertarget);
        }

        // GET: /CBikerTarget/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            BikerTarget bikertarget = db.BikerTargets.Find(id);
            if (bikertarget == null)
            {
                return HttpNotFound();
            }
            return View(bikertarget);
        }

        // POST: /CBikerTarget/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            BikerTarget bikertarget = db.BikerTargets.Find(id);
            db.BikerTargets.Remove(bikertarget);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
