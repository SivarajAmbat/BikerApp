﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Luminous.Biker.Web.Models;
using System.Collections;

namespace Luminous.Biker.Web.Controllers
{
    public class CBikerTargetController : Controller
    {


        private LuminousBikerAppEntities db = new LuminousBikerAppEntities();

        IEnumerable<SelectListItem> Months = new List<SelectListItem>() 
            {
                new SelectListItem{ Text= "January", Value="1", Selected=false},
                new SelectListItem{ Text= "February", Value="2", Selected=false},
                new SelectListItem{ Text= "March", Value="3", Selected=false},
                new SelectListItem{ Text= "April", Value="4", Selected=false},
                new SelectListItem{ Text= "May", Value="5", Selected=false},
                new SelectListItem{ Text= "June", Value="6", Selected=false},
                new SelectListItem{ Text= "July", Value="7", Selected=false},
                new SelectListItem{ Text= "August", Value="8", Selected=false},
                new SelectListItem{ Text= "September", Value="9", Selected=false},
                new SelectListItem{ Text= "October", Value="10", Selected=false},
                new SelectListItem{ Text= "November", Value="11", Selected=false},
                new SelectListItem{ Text= "December", Value="12", Selected=false},
            };

        // GET: /CBikerTarget/
        public ActionResult Index()
        {
            var bikertargets = db.BikerTargets.Include(b => b.BikerBoyDetail).Include(b => b.Item);
            IEnumerable<SelectListItem> months = Months;
            ViewBag.MonthFan = new SelectList(months, "Value", "Text");
            return View(bikertargets.ToList());
        }

        // GET: /CBikerTarget/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            BikerTarget bikertarget = db.BikerTargets.Include(b => b.BikerBoyDetail).Include(b => b.Item).Where(m => m.Id == id).FirstOrDefault();
            if (bikertarget == null)
            {
                return HttpNotFound();
            }
            return View(bikertarget);
        }

        // GET: /CBikerTarget/Create
        public ActionResult Create()
        {
            List < SelectListItem >  idBBCodeName = new List<SelectListItem>();
            var idBBCodeNameTemp = db.BikerBoyDetails.Select(m => new { BB_Code = m.BB_Code, BB_Name = m.BB_Name, ID = m.ID }).ToList();
            idBBCodeName.AddRange(idBBCodeNameTemp.Select(m => new SelectListItem { Text = m.BB_Code + " " + m.BB_Name, Value = Convert.ToString(m.ID), Selected = false }));
            ViewBag.BikerIdFan = idBBCodeName;
                //new SelectList(db.BikerBoyDetails, "ID", "BB_Code");
            //ViewBag.ItemIdFan = db.Items.Where(m => m.ItemName == "Fan").FirstOrDefault().ID; //new SelectList(db.Items, "ID", "ItemName", );

            //ViewBag.BikerIdWire = new SelectList(db.BikerBoyDetails, "ID", "BB_Code");
            //ViewBag.ItemIdWire = db.Items.Where(m => m.ItemName == "Wire").FirstOrDefault().ID; ;// new SelectList(db.Items, "ID", "ItemName");

            //ViewBag.BikerIdLighting = new SelectList(db.BikerBoyDetails, "ID", "BB_Code");
            //ViewBag.ItemIdLighting = db.Items.Where(m => m.ItemName == "Lighting").FirstOrDefault().ID; ;// new SelectList(db.Items, "ID", "ItemName");

            //int monthInitial = 1;
            //int monthFinal = 13;

            int yearInitial = 2000;
            int yearFinal = 2026;

            //IEnumerable<int> months = Enumerable.Range(monthInitial, monthFinal - monthInitial);

            IEnumerable<SelectListItem> months = Months;
            IEnumerable<int> years = Enumerable.Range(yearInitial, yearFinal - yearInitial);

            ViewBag.MonthFan = new SelectList(months,"Value","Text");
            ViewBag.YearFan = new SelectList(years);

            //ViewBag.MonthWire = new SelectList(months);
            //ViewBag.YearWire = new SelectList(years);

           // ViewBag.MonthLighting = new SelectList(months);
            //ViewBag.YearLighting = new SelectList(years);

            BikerTargetCustom bikerTargetCustom = new BikerTargetCustom
            {
                BikerTargetFan = new BikerTarget { ItemId = db.Items.Where(m => m.ItemName == "Fan").FirstOrDefault().ID },
                BikerTargetWire = new BikerTarget { ItemId = db.Items.Where(m => m.ItemName == "Wire").FirstOrDefault().ID },
                BikerTargetLighting = new BikerTarget { ItemId = db.Items.Where(m => m.ItemName == "Lighting").FirstOrDefault().ID }
            };

            return View(bikerTargetCustom);
        }

        // POST: /CBikerTarget/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(BikerTargetCustom bikerTargetCustom)
        {
            if (ModelState.IsValid)
            {
                bikerTargetCustom.BikerTargetWire.BikerId = bikerTargetCustom.BikerTargetFan.BikerId;
                bikerTargetCustom.BikerTargetLighting.BikerId = bikerTargetCustom.BikerTargetFan.BikerId;

                bikerTargetCustom.BikerTargetWire.MonthNumber = bikerTargetCustom.BikerTargetFan.MonthNumber;
                bikerTargetCustom.BikerTargetLighting.MonthNumber = bikerTargetCustom.BikerTargetFan.MonthNumber;

                bikerTargetCustom.BikerTargetWire.YearNumber = bikerTargetCustom.BikerTargetFan.YearNumber;
                bikerTargetCustom.BikerTargetLighting.YearNumber = bikerTargetCustom.BikerTargetFan.YearNumber;
                
                if (bikerTargetCustom != null && bikerTargetCustom.BikerTargetFan != null)
                {
                    BikerTarget bikerTarget = bikerTargetCustom.BikerTargetFan;
                    bikerTarget.CreatedOn = DateTime.Now;
                    bikerTarget.CreateBy = User.Identity.Name;
                    db.BikerTargets.Add(bikerTarget);
                    db.SaveChanges();
                }
                if (bikerTargetCustom != null && bikerTargetCustom.BikerTargetWire != null)
                {
                    BikerTarget bikerTarget = bikerTargetCustom.BikerTargetWire;
                    bikerTarget.CreatedOn = DateTime.Now;
                    bikerTarget.CreateBy = User.Identity.Name;
                    db.BikerTargets.Add(bikerTarget);
                    db.SaveChanges();
                }
                if (bikerTargetCustom != null && bikerTargetCustom.BikerTargetLighting != null)
                {
                    BikerTarget bikerTarget = bikerTargetCustom.BikerTargetLighting;
                    bikerTarget.CreatedOn = DateTime.Now;
                    bikerTarget.CreateBy = User.Identity.Name;
                    db.BikerTargets.Add(bikerTarget);
                    db.SaveChanges();
                }
                //T.Message = "Saved Successfully. Set next biker target.";
                return RedirectToAction("Index");
            }

            List<SelectListItem> idBBCodeName = new List<SelectListItem>();
            var idBBCodeNameTemp = db.BikerBoyDetails.Select(m => new { BB_Code = m.BB_Code, BB_Name = m.BB_Name, ID = m.ID }).ToList();
            idBBCodeName.AddRange(idBBCodeNameTemp.Select(m => new SelectListItem { Text = m.BB_Code + " " + m.BB_Name, Value = Convert.ToString(m.ID), Selected = false }));
            //ViewBag.BikerIdFan = idBBCodeName;

            ViewBag.BikerIdFan = new SelectList(idBBCodeName, "Value", "Text", bikerTargetCustom.BikerTargetFan.BikerId);
            //ViewBag.ItemIdFan = new SelectList(db.Items, "ID", "ItemName", bikerTargetCustom.BikerTargetFan.ItemId);

            //ViewBag.BikerIdWire = new SelectList(db.BikerBoyDetails, "ID", "BB_Code", bikerTargetCustom.BikerTargetWire.BikerId);
            //ViewBag.ItemIdWire = new SelectList(db.Items, "ID", "ItemName", bikerTargetCustom.BikerTargetWire.ItemId);

            //ViewBag.BikerIdLighting = new SelectList(db.BikerBoyDetails, "ID", "BB_Code", bikerTargetCustom.BikerTargetLighting.BikerId);
            //ViewBag.ItemIdLighting = new SelectList(db.Items, "ID", "ItemName", bikerTargetCustom.BikerTargetLighting.ItemId);

            //int monthInitial = 1;
            //int monthFinal = 13;

            int yearInitial = 2000;
            int yearFinal = 2026;

            IEnumerable<SelectListItem> months = Months;
            IEnumerable<int> years =  Enumerable.Range(yearInitial, yearFinal - yearInitial);

            ViewBag.MonthFan = new SelectList(months, "Value", "Text", bikerTargetCustom.BikerTargetFan.MonthNumber);
            ViewBag.YearFan = new SelectList(years, bikerTargetCustom.BikerTargetFan.YearNumber);

            //ViewBag.MonthWire = new SelectList(months, bikerTargetCustom.BikerTargetWire.MonthNumber);
            //ViewBag.YearWire = new SelectList(years, bikerTargetCustom.BikerTargetWire.YearNumber);

            //ViewBag.MonthLighting = new SelectList(months, bikerTargetCustom.BikerTargetLighting.MonthNumber);
            //ViewBag.YearLighting = new SelectList(years, bikerTargetCustom.BikerTargetLighting.YearNumber);

            return View(bikerTargetCustom);
        }

        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult Create(BikerTarget bikerTarget)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        if (bikerTarget != null)
        //        {
        //            bikerTarget.CreatedOn = DateTime.Now;
        //            bikerTarget.CreateBy = User.Identity.Name;
        //            db.BikerTargets.Add(bikerTarget);
        //            db.SaveChanges();
        //        }
        //        return RedirectToAction("Index");
        //    }

        //    ViewBag.BikerId = new SelectList(db.BikerBoyDetails, "ID", "BB_Code", bikerTarget.BikerId);
        //    ViewBag.ItemId = new SelectList(db.Items, "ID", "ItemName", bikerTarget.ItemId);
        //    return View(bikerTarget);
        //}

        // GET: /CBikerTarget/Edit/5
        public ActionResult Edit(int? id)
       
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            BikerTarget bikertarget = db.BikerTargets.Find(id);
            if (bikertarget == null)
            {
                return HttpNotFound();
            }

            //int monthInitial = 1;
            //int monthFinal = 13;

            int yearInitial = 2000;
            int yearFinal = 2026;

            IEnumerable<SelectListItem> months = Months;
            IEnumerable<int> years = Enumerable.Range(yearInitial, yearFinal - yearInitial);

            ViewBag.MonthFan = new SelectList(months,"Value","Text", bikertarget.MonthNumber);
            ViewBag.YearFan = new SelectList(years, bikertarget.YearNumber);

            List<SelectListItem> idBBCodeName = new List<SelectListItem>();
            var idBBCodeNameTemp = db.BikerBoyDetails.Select(m => new { BB_Code = m.BB_Code, BB_Name = m.BB_Name, ID = m.ID }).ToList();
            idBBCodeName.AddRange(idBBCodeNameTemp.Select(m => new SelectListItem { Text = m.BB_Code + " " + m.BB_Name, Value = Convert.ToString(m.ID), Selected = false }));
            //ViewBag.BikerIdFan = idBBCodeName;

            ViewBag.BikerId = new SelectList(idBBCodeName, "Value", "Text", bikertarget.BikerId);

           // ViewBag.BikerId = new SelectList(db.BikerBoyDetails, "ID", "BB_Code", bikertarget.BikerId);
            ViewBag.ItemId = new SelectList(db.Items, "ID", "ItemName", bikertarget.ItemId);

            return View(bikertarget);
        }

        // POST: /CBikerTarget/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include="Id,BikerId,ItemId,TargetQuantity,CreatedOn,CreateBy,UpdatedOn,UpdatedBy,YearNumber,MonthNumber")] BikerTarget bikertarget)
        {
            if (ModelState.IsValid)
            {
                bikertarget.UpdatedOn = DateTime.Now;
                bikertarget.UpdatedBy = User.Identity.Name;
                db.Entry(bikertarget).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            //int monthInitial = 1;
            //int monthFinal = 13;

            int yearInitial = 2000;
            int yearFinal = 2026;

            IEnumerable<SelectListItem> months = Months;
            IEnumerable<int> years = Enumerable.Range(yearInitial, yearFinal - yearInitial);

            ViewBag.MonthFan = new SelectList(months, "Value", "Text", bikertarget.MonthNumber);
            ViewBag.YearFan = new SelectList(years, bikertarget.YearNumber);

            List<SelectListItem> idBBCodeName = new List<SelectListItem>();
            var idBBCodeNameTemp = db.BikerBoyDetails.Select(m => new { BB_Code = m.BB_Code, BB_Name = m.BB_Name, ID = m.ID }).ToList();
            idBBCodeName.AddRange(idBBCodeNameTemp.Select(m => new SelectListItem { Text = m.BB_Code + " " + m.BB_Name, Value = Convert.ToString(m.ID), Selected = false }));
            ViewBag.BikerId = new SelectList(idBBCodeName, "Value", "Text", bikertarget.BikerId);

            //ViewBag.BikerId = new SelectList(db.BikerBoyDetails, "ID", "BB_Code", bikertarget.BikerId);
            ViewBag.ItemId = new SelectList(db.Items, "ID", "ItemName", bikertarget.ItemId);
            return View(bikertarget);
        }

        // GET: /CBikerTarget/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            BikerTarget bikertarget = db.BikerTargets.Include(b => b.BikerBoyDetail).Include(b => b.Item).Where(m => m.Id == id).FirstOrDefault();
            if (bikertarget == null)
            {
                return HttpNotFound();
            }
            return View(bikertarget);
        }

        // POST: /CBikerTarget/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            BikerTarget bikertarget = db.BikerTargets.Include(b => b.BikerBoyDetail).Include(b => b.Item).Where(m => m.Id == id).FirstOrDefault();
            db.BikerTargets.Remove(bikertarget);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
