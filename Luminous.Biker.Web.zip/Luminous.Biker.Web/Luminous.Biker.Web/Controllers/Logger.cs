﻿using Luminous.Biker.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Luminous.Biker.Web.Controllers
{
    public class ExceptionLogger
    {
        private LuminousBikerAppEntities db = new LuminousBikerAppEntities();


        public String ActionName { get; set; }
        public String ControllerName { get; set; }
        public Exception ExceptionObj { get; set; }

        public string UserName { get; set; }
        public ExceptionLogger(ExceptionContext filterContext)
        {
            // TODO: Complete member initialization
            if (filterContext != null)
            {
                string controllerName = Convert.ToString(filterContext.RouteData.Values["controller"]);
                string actionName = Convert.ToString(filterContext.RouteData.Values["action"]);
                Exception exception = filterContext.Exception;
                string userName = filterContext.HttpContext.User.Identity.Name;
                this.ActionName = actionName;
                this.ControllerName = controllerName;
                this.ExceptionObj = exception;
                this.UserName = userName;
                LogException();
            }

        }

        private void LogException()
        {
            Logger logger = new Logger();
            if (ExceptionObj != null)
                logger = new Models.Logger { Message = ActionName + " | " + ControllerName + " | ExceptionMessage" + ExceptionObj.Message, StackTrace = ExceptionObj.StackTrace, CreatedOn = DateTime.Now, CreatedBy = UserName };
            else if (ExceptionObj == null)
                logger = new Models.Logger { Message = ActionName + " | " + ControllerName + " | ExceptionMessage" + "", CreatedOn = DateTime.Now, CreatedBy = UserName };
            db.Loggers.Add(logger);
            db.SaveChanges();
        }


    }
}