﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Luminous.Biker.Web.Models;
using Newtonsoft.Json;

namespace Luminous.Biker.Web.Controllers
{
    public class RetailerMappingToBeatController : Controller
    {
        private LuminousBikerAppEntities db = new LuminousBikerAppEntities();

        public ActionResult List(string distId)
        {
            if(!String.IsNullOrEmpty(distId))
            {
                ViewBag.DistId = distId;
                List<RetailBeatMapping> retailBeatMappings = db.RetailBeatMappings.Include(r => r.BeatDetail).Include(r => r.RetailerDetail).Include(r => r.BeatDetail.BeatDistributorMappings).Where(m => m.BeatDetail.BeatDistributorMappings.Where(n => n.DistDealerDetail.Dis_Sap_Code == distId).Count() > 0).Select(m => m).ToList();
    //            db.DistDealerDetails.Join(RetailBeatMappings, m => m.Dis_Sap_Code, n=> n.BeatDetail.BeatDistributorMappings.SelectMany(r => r.DistDealerDetail.Dis_Sap_Code))

    //            List<RetailBeatMapping> retailBeatMappings = new List<RetailBeatMapping>();
    //            foreach (var item in RetailBeatMappings)
    //{
    //     if(item.BeatDetail.BeatDistributorMappings.Select(m => m.DistDealerDetail.Dis_Sap_Code))
    //}
                //RetailBeatMappings= RetailBeatMappings.
                return View(retailBeatMappings);
            }
            return View(new List<RetailBeatMapping>());
        }

        public ActionResult Index()
        {
            List<RetailBeatMapping> retailbeatmappings=new List<RetailBeatMapping>();
            if(this.HttpContext.User.IsInRole("Coordinator") && !this.HttpContext.User.IsInRole("Admin"))
                retailbeatmappings = db.RetailBeatMappings.Include(r => r.BeatDetail).Include(r => r.RetailerDetail)
                    .Where(m => m.RetailerDetail.Active_Status == "Active").ToList();
            else if(this.HttpContext.User.IsInRole("Admin"))
                retailbeatmappings = db.RetailBeatMappings.Include(r => r.BeatDetail).Include(r => r.RetailerDetail).ToList();
            return View(retailbeatmappings.ToList());
        }

        // GET: /RetailerMappingToBeat/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            RetailBeatMapping retailbeatmapping = db.RetailBeatMappings.Find(id);
            if (retailbeatmapping == null)
            {
                return HttpNotFound();
            }
            return View(retailbeatmapping);
        }

        // GET: /RetailerMappingToBeat/Create
        public ActionResult Create(string distId)
        {
            if(!String.IsNullOrEmpty(distId))
                ViewBag.DistId = distId;
            ViewBag.Beat_Id = new SelectList(db.BeatDetails, "ID", "Code");
            ViewBag.Retailer_Id = new SelectList(db.RetailerDetails, "ID", "Code");
            return View();
        }

        // POST: /RetailerMappingToBeat/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include="ID,Beat_Id,Retailer_Id")] RetailBeatMapping retailbeatmapping)
        {
            if (ModelState.IsValid)
            {
                db.RetailBeatMappings.Add(retailbeatmapping);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.Beat_Id = new SelectList(db.BeatDetails, "ID", "Code", retailbeatmapping.Beat_Id);
            ViewBag.Retailer_Id = new SelectList(db.RetailerDetails, "ID", "Code", retailbeatmapping.Retailer_Id);
            return View(retailbeatmapping);
        }

        // GET: /RetailerMappingToBeat/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            RetailBeatMapping retailbeatmapping = db.RetailBeatMappings.Find(id);
            if (retailbeatmapping == null)
            {
                return HttpNotFound();
            }
            ViewBag.Beat_Id = new SelectList(db.BeatDetails, "ID", "Code", retailbeatmapping.Beat_Id);
            ViewBag.Retailer_Id = new SelectList(db.RetailerDetails, "ID", "Code", retailbeatmapping.Retailer_Id);
            return View(retailbeatmapping);
        }

        // POST: /RetailerMappingToBeat/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include="ID,Beat_Id,Retailer_Id")] RetailBeatMapping retailbeatmapping)
        {
            if (ModelState.IsValid)
            {
                db.Entry(retailbeatmapping).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Beat_Id = new SelectList(db.BeatDetails, "ID", "Code", retailbeatmapping.Beat_Id);
            ViewBag.Retailer_Id = new SelectList(db.RetailerDetails, "ID", "Code", retailbeatmapping.Retailer_Id);
            return View(retailbeatmapping);
        }

        // GET: /RetailerMappingToBeat/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            RetailBeatMapping retailbeatmapping = db.RetailBeatMappings.Find(id);
            if (retailbeatmapping == null)
            {
                return HttpNotFound();
            }
            return View(retailbeatmapping);
        }

        // POST: /RetailerMappingToBeat/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            RetailBeatMapping retailbeatmapping = db.RetailBeatMappings.Find(id);
            db.RetailBeatMappings.Remove(retailbeatmapping);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        [HttpGet]
        public string GetMappedRetailerByBeatId(int? beatId)
        {
            List<int> retailerMappedIds = db.RetailBeatMappings.Where(m => m.Beat_Id != null && m.Retailer_Id != null && m.Beat_Id == beatId)
                .Select(m => m.Retailer_Id).ToList();
            return JsonConvert.SerializeObject(retailerMappedIds);
        }

        [HttpPost]
        public string UpdateMappingRetailerAndBeat(int beatId, List<int> retailerIds)
        {
            string message = "";
            try
            {
                if (retailerIds != null)
                {
                    List<RetailBeatMapping> mappingRetailers = db.RetailBeatMappings.Where(m => m.Beat_Id == beatId).ToList();
                    if (mappingRetailers != null)
                    {
                        foreach (var item in mappingRetailers)
                        {
                            if (!retailerIds.Contains(item.Retailer_Id))
                            {
                                db.RetailBeatMappings.Remove(item);
                            }
                        }
                        db.SaveChanges();
                    }
                    mappingRetailers = db.RetailBeatMappings.Where(m => m.Beat_Id == beatId).ToList();
                    if (mappingRetailers != null)
                    {
                        foreach (var item in retailerIds)
                        {
                            if ((mappingRetailers.All(m => m.Retailer_Id != item)))
                            {
                                db.RetailBeatMappings.Add(new RetailBeatMapping { Retailer_Id = item, Beat_Id = beatId });
                            }
                        }
                        db.SaveChanges();
                    }
                    message = "Updated Successfully";
                }
                else
                {
                    message = "Please select Beat and Retailer";
                }
            }
            catch (Exception)
            {
                message = "Some Error occured. Please try again";
            }

            return JsonConvert.SerializeObject(message);
        }



        [HttpGet, ActionName("SearchBeat")]
        public ActionResult SearchBeat(string searchParameter)
        {
            //return "Hello World";
            return PartialView("_BeatRadio", searchParameter);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        protected override void OnException(ExceptionContext filterContext)
        {
            if (filterContext.ExceptionHandled)
            {
                return;
            }
            string controllerName = Convert.ToString(filterContext.RouteData.Values["controller"]);
            string actionName = Convert.ToString(filterContext.RouteData.Values["action"]);
            Exception exception = filterContext.Exception;
            new ExceptionLogger(filterContext);
            filterContext.Result = new ViewResult
            {
                ViewName = "~/Views/Shared/Error.cshtml"
            };
            filterContext.ExceptionHandled = true;
        }
    }
}
