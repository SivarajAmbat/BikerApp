﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Luminous.Biker.Web.Models;
using Newtonsoft.Json;

namespace Luminous.Biker.Web.Controllers
{
    public class BikerBoyMappingToRetailerController : Controller
    {
        private LuminousBikerAppEntities db = new LuminousBikerAppEntities();

        // GET: /BikerBoyMappingToRetailer/
        public ActionResult Index()
        {
            var bikerretailermappings = db.BikerRetailerMappings.Include(b => b.BikerBoyDetail).Include(b => b.RetailerDetail);
            return View(bikerretailermappings.ToList());
        }

        // GET: /BikerBoyMappingToRetailer/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            BikerRetailerMapping bikerretailermapping = db.BikerRetailerMappings.Find(id);
            if (bikerretailermapping == null)
            {
                return HttpNotFound();
            }
            return View(bikerretailermapping);
        }

        // GET: /BikerBoyMappingToRetailer/Create
        public ActionResult Create()
        {
            ViewBag.BikerId = new SelectList(db.BikerBoyDetails, "ID", "BB_Code");
            ViewBag.RetailerId = new SelectList(db.RetailerDetails, "ID", "Code");
            return View();
        }

        // POST: /BikerBoyMappingToRetailer/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include="Id,BikerId,RetailerId")] BikerRetailerMapping bikerretailermapping)
        {
            if (ModelState.IsValid)
            {
                db.BikerRetailerMappings.Add(bikerretailermapping);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.BikerId = new SelectList(db.BikerBoyDetails, "ID", "BB_Code", bikerretailermapping.BikerId);
            ViewBag.RetailerId = new SelectList(db.RetailerDetails, "ID", "Code", bikerretailermapping.RetailerId);
            return View(bikerretailermapping);
        }

        // GET: /BikerBoyMappingToRetailer/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            BikerRetailerMapping bikerretailermapping = db.BikerRetailerMappings.Find(id);
            if (bikerretailermapping == null)
            {
                return HttpNotFound();
            }
            ViewBag.BikerId = new SelectList(db.BikerBoyDetails, "ID", "BB_Code", bikerretailermapping.BikerId);
            ViewBag.RetailerId = new SelectList(db.RetailerDetails, "ID", "Code", bikerretailermapping.RetailerId);
            return View(bikerretailermapping);
        }

        // POST: /BikerBoyMappingToRetailer/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include="Id,BikerId,RetailerId")] BikerRetailerMapping bikerretailermapping)
        {
            if (ModelState.IsValid)
            {
                db.Entry(bikerretailermapping).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.BikerId = new SelectList(db.BikerBoyDetails, "ID", "BB_Code", bikerretailermapping.BikerId);
            ViewBag.RetailerId = new SelectList(db.RetailerDetails, "ID", "Code", bikerretailermapping.RetailerId);
            return View(bikerretailermapping);
        }

        // GET: /BikerBoyMappingToRetailer/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            BikerRetailerMapping bikerretailermapping = db.BikerRetailerMappings.Find(id);
            if (bikerretailermapping == null)
            {
                return HttpNotFound();
            }
            return View(bikerretailermapping);
        }

        // POST: /BikerBoyMappingToRetailer/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            BikerRetailerMapping bikerretailermapping = db.BikerRetailerMappings.Find(id);
            db.BikerRetailerMappings.Remove(bikerretailermapping);
            db.SaveChanges();
            return RedirectToAction("Index");
        }


        [HttpGet]
        public string GetMappedRetailerByBikerId(int? bikerId)
        {
            List<int> retailerMappedIds = db.BikerRetailerMappings.Where(m => m.BikerId != null && m.RetailerId != null && m.BikerId == bikerId)
                .Select(m => m.RetailerId).ToList();
            return JsonConvert.SerializeObject(retailerMappedIds);
        }

        [HttpPost]
        public string UpdateMappingRetailerAndBiker(int bikerId, List<int> retailerIds)
        {
            string message = "";
            try
            {
                if (retailerIds != null)
                {
                    List<BikerRetailerMapping> mappingRetailers = db.BikerRetailerMappings.Where(m => m.BikerId == bikerId).ToList();
                    if (mappingRetailers != null)
                    {
                        foreach (var item in mappingRetailers)
                        {
                            if (!retailerIds.Contains(item.RetailerId))
                            {
                                db.BikerRetailerMappings.Remove(item);
                            }
                        }
                        db.SaveChanges();
                    }
                    mappingRetailers = db.BikerRetailerMappings.Where(m => m.BikerId == bikerId).ToList();
                    if (mappingRetailers != null)
                    {
                        foreach (var item in retailerIds)
                        {
                            if ((mappingRetailers.All(m => m.RetailerId != item)))
                            {
                                db.BikerRetailerMappings.Add(new BikerRetailerMapping { RetailerId = item, BikerId = bikerId });
                            }
                        }
                        db.SaveChanges();
                    }
                    message = "Updated Successfully";
                }
                else
                {
                    message = "Please select Biker and Retailer";
                }
            }
            catch (Exception)
            {
                message = "Some Error occured. Please try again";
            }

            return JsonConvert.SerializeObject(message);
        }



        [HttpGet, ActionName("SearchBiker")]
        public ActionResult SearchBiker(string searchParameter)
        {
            //return "Hello World";
            return PartialView("_BikerRadio", searchParameter);
        }


        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
