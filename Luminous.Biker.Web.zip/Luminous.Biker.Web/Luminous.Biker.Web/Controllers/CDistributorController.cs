﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Luminous.Biker.Web.Models;

namespace Luminous.Biker.Web.Controllers
{
    [Authorize]
    public class CDistributorController : Controller
    {
        private LuminousBikerAppEntities db = new LuminousBikerAppEntities();

        //
        // GET: /CDistributor/

        public ActionResult Index()
        {
            return View(db.DistDealerDetails.ToList());
        }

        //
        // GET: /CDistributor/Details/5

        public ActionResult Details(int id = 0)
        {
            DistDealerDetail distdealerdetail = db.DistDealerDetails.Find(id);
            if (distdealerdetail == null)
            {
                return HttpNotFound();
            }
            return View(distdealerdetail);
        }

        //
        // GET: /CDistributor/Create

        public ActionResult Create()
        {
            ViewBag.Active = new SelectList(ActiveStatus.GetIEStatus(), "StatusValue", "StatusValue");
            return View();
        }

        //
        // POST: /CDistributor/Create

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(DistDealerDetail distdealerdetail)
        {
            if (ModelState.IsValid)
            {
                List<string> codes = db.DistDealerDetails.Where(m => m.IsCreated != null && m.IsCreated)
                    .Select(m => m.Dis_Sap_Code).ToList();
                string code = string.Empty;
                if (codes != null && codes.Count > 0)
                    code = Convert.ToString(codes.Select(m => Convert.ToDouble(m)).Max() + 1);
                else
                    code = "8000000001";
                distdealerdetail.Dis_Sap_Code = code;
                distdealerdetail.IsCreated = true;

                distdealerdetail.Created_On = DateTime.Now;
                db.DistDealerDetails.Add(distdealerdetail);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Active = new SelectList(ActiveStatus.GetIEStatus(), "StatusValue", "StatusValue");
            return View(distdealerdetail);
        }

        //
        // GET: /CDistributor/Edit/5

        public ActionResult Edit(int id = 0)
        {
            DistDealerDetail distdealerdetail = db.DistDealerDetails.Find(id);
            if (distdealerdetail == null)
            {
                return HttpNotFound();
            }
            ViewBag.Active = new SelectList(ActiveStatus.GetIEStatus(), "StatusValue", "StatusValue");
            return View(distdealerdetail);
        }

        //
        // POST: /CDistributor/Edit/5

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(DistDealerDetail distdealerdetail)
        {
            if (ModelState.IsValid)
            {
                if (distdealerdetail != null && distdealerdetail.ID > 0)
                {
                    //DistDealerDetail distdealerdetailOrg = db.DistDealerDetails.Find(distdealerdetail.ID);
                    distdealerdetail.Updated_On = DateTime.Now;
                    //distdealerdetail.Created_On = distdealerdetailOrg.Created_On;
                    //db.SaveChanges();
                }
                //db.Entry(v)
               // db.DistDealerDetails.Attach(distdealerdetail);
                db.Entry(distdealerdetail).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Active = new SelectList(ActiveStatus.GetIEStatus(), "StatusValue", "StatusValue");
            return View(distdealerdetail);
        }

        //
        // GET: /CDistributor/Delete/5

        public ActionResult Delete(int id = 0)
        {
            DistDealerDetail distdealerdetail = db.DistDealerDetails.Find(id);
            if (distdealerdetail == null)
            {
                return HttpNotFound();
            }
            return View(distdealerdetail);
        }

        //
        // POST: /CDistributor/Delete/5

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            DistDealerDetail distdealerdetail = db.DistDealerDetails.Find(id);
            db.DistDealerDetails.Remove(distdealerdetail);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        //[HttpGet, ActionName("SearchDistributor")]
        //public string SearchDistributor(string searchParameter)
        //{
        //    return "Hello World";
        //    //return PartialView("_DistributorRadio", searchParameter);
        //}

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }

        protected override void OnException(ExceptionContext filterContext)
        {
            if (filterContext.ExceptionHandled)
            {
                return;
            }
            
            
            new ExceptionLogger(filterContext);
            filterContext.Result = new ViewResult
            {
                ViewName = "~/Views/Shared/Error.cshtml"
            };
            filterContext.ExceptionHandled = true;
        }
    }
}