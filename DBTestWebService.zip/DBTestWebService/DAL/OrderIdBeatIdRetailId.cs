﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
    public class OrderIdBeatIdRetailId
    {
        public int Order_ID { get; set; }

        public string Beat_Code { get; set; }
        public string Beat_Name { get; set; }
        public string Retailer_Code { get; set; }
        public string Retailer_Name { get; set; }
        public string Destributor_Code { get; set; }
        public string Destributor_Name { get; set; }
    }
}
