﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
    public class OrderItemSave
    {

        public int? Item_Id { get; set; }

        public double? Required_Quantity { get; set; }

    }
}
